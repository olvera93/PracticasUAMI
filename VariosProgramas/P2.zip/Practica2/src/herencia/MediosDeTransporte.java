package herencia;

public class MediosDeTransporte {
	
	private String alcance;
	private double precio;
	
	public MediosDeTransporte(String alcance, double precio) {
		super();
		this.alcance = alcance;
		this.precio = precio;
	}

	public String getAlcance() {
		return "El alcance es: " + alcance;
	}
	
	public double getPrecio() {
		return precio;
	}
	
	public String getInformacion() {
		return alcance + " " + precio;
	}
}
