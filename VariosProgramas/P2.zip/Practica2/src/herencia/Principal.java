package herencia;

public class Principal {

	public static void main(String[] args) {
		
		Auto aveo= new Auto("Personal", 100000, 4, "Familiar");
		System.out.println("La informacion es: "+aveo.getInformacion());
		
		Bicicleta benotto= new Bicicleta("Personal", 3500, 2, "bmx");
		System.out.println("La informacion es: "+benotto.getInformacion());
		
		MediosDeTransporte ovni= new MediosDeTransporte("Espacial ", 5463);
		System.out.println("La informacion es: "+ovni.getInformacion());
		
		Terrestre camion= new Terrestre("Masivo", 2250000, 6);
		System.out.println("La informacion es: "+camion.getInformacion()+" "+camion.getRuedas());
	}

}
