package herencia;

public class Auto extends Terrestre {
	
	private String tipo;
	
	public Auto(String alcance, double precio, int ruedas, String tipo) {
		super(alcance, precio, ruedas);
		this.tipo = tipo;
	}

	public String getInformacion() {
		return getAlcance() + " " + getPrecio() + " " + getRuedas() + " " + tipo;
	}

}
