package sobrescrituraDeMetodos;

public class B extends A {
	
	int k;

	public B(int i, int j, int k) {
		super(i, j);
		this.k=k ;
		
		show();//llama al show de B
		//super.show();
	}

	public void show() {
		//super.show();
		System.out.println("Soy el metodo show de B "+i+" "+ j+ " " + k);
	}
	
	public void show(int a) {
		System.out.println(a);
	}

}
