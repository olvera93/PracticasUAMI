package sobrescrituraDeMetodos;

public class Principal {

	public static void main(String[] args) {
		
		B b= new B(1,2,3);
		
		//b.show();
		b.show(10);
		
		A a= new A(3,9);
		
		a.show(10);
		
		
	}

}
