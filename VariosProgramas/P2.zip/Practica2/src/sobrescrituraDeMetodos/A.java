package sobrescrituraDeMetodos;

public class A {
	
	int i;
	int j;

	public A(int i, int j) {
		this.i=i;
		this.j=j;
	}
	
	public void show() {
		System.out.println("Soy el metodo show de A "+"i: "+i+" " + "j: "+j);
	}
	
	public void show(int a) {
		System.out.println(a);
	}

}
