package metodosDinamicos;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Figura f= new Figura(3,4);
		Rectangulo r= new Rectangulo(5,7);
		Triangulo t= new Triangulo(8,9);
		
		/*double x=f.area();
		System.out.println(x);*/
		//seleccion estatica de metodos
		System.out.println(f.area());
		System.out.println(r.area());
		System.out.println(t.area());
		//seleccion dinamica
		
		Figura figref;
		figref=f;
		System.out.println(figref.area());
		figref=r;
		System.out.println(figref.area());
		figref=t;
		System.out.println(figref.area());
		
	}

}
