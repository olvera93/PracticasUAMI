package metodosDinamicos;

public class Rectangulo extends Figura {

	public Rectangulo(int dim1, int dim2) {
		super(dim1, dim2);
		// TODO Auto-generated constructor stub
	}
	
	double area() {
		System.out.println("El area de un rectangulo");
		return dim1*dim2;
	}

}
