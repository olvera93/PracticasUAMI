package metodosDinamicos;

public class Triangulo extends Figura {

	public Triangulo(int dim1, int dim2) {
		super(dim1, dim2);
		// TODO Auto-generated constructor stub
	}
	
	double area() {
		System.out.println("El area de un triangulo");
		return (dim1*dim2)/2;
	}

}
