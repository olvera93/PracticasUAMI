package metodosDinamicos;

public class Figura {
	
	int dim1;
	int dim2;
	
	public Figura(int dim1, int dim2) {
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
	}	
	
	double area() {
		System.out.println("No se conoce la figura");
		return 0;
	}
}
