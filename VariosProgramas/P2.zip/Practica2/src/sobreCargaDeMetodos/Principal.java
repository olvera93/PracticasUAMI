package sobreCargaDeMetodos;

public class Principal {

	public static void main(String[] args) {
		
		double i=12;
		
		OverloadDemo inst= new OverloadDemo();
		
		inst.test(i);
		inst.test(3, 5);
		inst.test(12.5);
		
		inst.test();
	}

}
