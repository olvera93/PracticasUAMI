package sobreCargaDeMetodos;

public class OverloadDemo {
	
	public void test(){
		System.out.println("Soy el test sin argumentos");
	}
	
	public void test(int d) {
		System.out.println("d: "+d);
	}
	
	public void test(int a, int b) {
		System.out.println("a: "+a+" b: "+b);
	}
	
	public void test(double c) {
		System.out.println("c: "+c);
	}

}
