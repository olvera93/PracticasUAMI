
public class Principal {

	public static void main(String[] args) {

		String cadena = "(A+B)/(C^D)";
		System.out.println(Pila.infija_Posfija(cadena));
		
	}

}
