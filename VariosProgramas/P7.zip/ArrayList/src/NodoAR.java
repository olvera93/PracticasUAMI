
public class NodoAR {
	
	int dato;
	NodoAR izq;
	NodoAR der;
	
	
	public NodoAR(int dato, NodoAR izq, NodoAR der) {
		this.dato = dato;
		this.izq = izq;
		this.der = der;
	}

	NodoAR(){
		
	}

	public static NodoAR insertaArbol(int dato, NodoAR izq, NodoAR der){
	   NodoAR aux = new NodoAR();
	   aux.dato=dato;
	   aux.izq=izq;
	   aux.der=der;
	   
	   return aux;
	}

	
	private static void orden(NodoAR aux4) {
		
		if(aux4!=null){
			orden(aux4.izq);
			System.out.print(aux4.dato + " ");
			orden(aux4.der);
		}
	}
	
	public static void order2(NodoAR aux) {
		System.out.println("\nORDER:");
		orden(aux);
		System.out.println();
	}
	

}
