import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {

		ArrayList<Integer> x = new ArrayList<Integer>();
		ArrayList<NodoAR> PilaAr = new ArrayList<NodoAR>();
				
				
		x.add(10);
		x.add(20);	
		x.add(30);
								
		System.out.println(x.remove(x.size()-1));
		System.out.println(x.remove(x.size()-1));
		System.out.println(x.remove(x.size()-1));

		//Insertar arbol en una pila
		NodoAR a,b,c,d,e,f,g,h,i,j,k,l;
		
		b = new NodoAR(4, null, null);
		c = new NodoAR(6, null, null);
		a = new NodoAR(5, b, c);
		
		f = new NodoAR(15, null, null);
		e = new NodoAR(8, null, null);
		d = new NodoAR(10, e, f);
		
		l = new NodoAR(6, null, null);
		k = new NodoAR(5, null, null);
		j = new NodoAR(4, k, l);
		i = new NodoAR(3, null, null);
		h = new NodoAR(2, i, j);
		g = new NodoAR(1, h, null);
		
		
		NodoAR.order2(a);
		NodoAR.order2(d);
		NodoAR.order2(g);
		
		PilaAr.add(0, a);
		PilaAr.add(0, d);
		PilaAr.add(0, g);
		
		a = null;
		d = null;
		g = null;
		
		NodoAR aux;
		aux=PilaAr.remove(0);
		NodoAR.order2(aux);
		aux=PilaAr.remove(0);
		NodoAR.order2(aux);		
		aux=PilaAr.remove(0);
		NodoAR.order2(aux);		
		
				
	}
}
