import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ventana extends JFrame implements ActionListener, ItemListener {
	
	JCheckBox amplitud,orden,preorden,postorden,max,min;
	JTextField txt_amplitud;
	JTextField txt_orden;
	JTextField txt_preorden;
	JTextField txt_postorden;
	JTextField txt_max;
	JTextField txt_min;
	JPanel panel,panel2;
	JButton insertar,eliminar,buscar;
	NodoABB arbol;
	NodoABB arbol2;

	public Ventana(String title) throws HeadlessException {
		super(title);
		
		setSize(350,220);
		setLocationRelativeTo(null);
		
		
		
		
		
		amplitud = new JCheckBox("Amplitud");
		orden = new JCheckBox("Orden");
		preorden = new JCheckBox("PreOrden");
		postorden = new JCheckBox("PostOrden");
		max = new JCheckBox("Maximo");
		min = new JCheckBox("Minimo");
		
		txt_amplitud = new JTextField();
		txt_orden = new JTextField();
		txt_preorden = new JTextField();
		txt_postorden = new JTextField();
		txt_max = new JTextField();
		txt_min = new JTextField();
		
		insertar = new JButton("Insertar");
		buscar = new JButton("Buscar");
		eliminar = new JButton("Eliminar");
		
		panel = new JPanel();
		panel2 = new JPanel();
		
		panel2.setLayout(new FlowLayout());
		panel2.add(insertar);
		panel2.add(buscar);
		panel2.add(eliminar);
		
		
		panel.setLayout(new GridLayout(6,2));
		panel.add(amplitud);
		panel.add(txt_amplitud);
		panel.add(orden);
		panel.add(txt_orden);
		panel.add(preorden);
		panel.add(txt_preorden);
		panel.add(postorden);
		panel.add(txt_postorden);
		panel.add(max);
		panel.add(txt_max);
		panel.add(min);
		panel.add(txt_min);
		
		add(panel, "South");
		add(panel2, "North");
		
		amplitud.addItemListener(this);
		orden.addItemListener(this);
		preorden.addItemListener(this);
		postorden.addItemListener(this);
		max.addItemListener(this);
		min.addItemListener(this);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		
	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}



	@Override
	public void itemStateChanged(ItemEvent e) {
		if(amplitud.isSelected()) {
			
		}else {
			amplitud.setText("");
		}
		
		if(orden.isSelected()) {
			//txt_orden.setText(ABB.recorreOrden(arbol));
		}else {
			txt_orden.setText("");
		}
		
	}

}
