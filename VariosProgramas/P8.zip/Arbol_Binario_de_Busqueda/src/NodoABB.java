
public class NodoABB {

	int dato;
	NodoABB izq;
	NodoABB der;
	static String cad = "";
	
	
	public NodoABB(int dato, NodoABB izq, NodoABB der) {
		super();
		this.dato = dato;
		this.izq = izq;
		this.der = der;
	}
	
	private NodoABB insertaABB(NodoABB arbol, int dato) {
		if(arbol == null) {
			arbol = new NodoABB(dato, null, null);
		}else { //Al menos tengo un dato
			if(dato < arbol.dato) {
				return arbol.izq = insertaABB(arbol.izq, dato);
			}else {
				return arbol.der = insertaABB(arbol.der, dato);
			}
		}
		return arbol;
	}
	
	public static String recorreO(NodoABB arbol) {
		if(arbol != null){
			recorreO(arbol.izq);
			cad = String.valueOf(cad) + arbol.dato + " ";
			recorreO(arbol.der);
		}
		return cad;
			
	}
	
	private int encontrarMaximo(NodoABB arbol) {
		if(arbol != null) {
			if(arbol.der == null) {
				return arbol.dato;
			}else {
				return encontrarMaximo(arbol.der);
			}
		}else {
			return -1;
		}
	}
	
	private int encontrarMinimo(NodoABB arbol) {
		if(arbol != null) {
			if(arbol.izq == null) {
				return arbol.dato;
			}else {
				return encontrarMaximo(arbol.izq);
			}
		}else {
			return -1;
		}
	}
	
	private boolean buscarElementos(NodoABB arbol, int dato) {
		if(arbol != null) {
			if(arbol.dato == dato) {
				return true;
			}else {
				if(dato < arbol.dato) {
					return buscarElementos(arbol.izq, dato);
				}else {
					return buscarElementos(arbol.der, dato);
				}
			}
		}else
			return false;
	}

}
